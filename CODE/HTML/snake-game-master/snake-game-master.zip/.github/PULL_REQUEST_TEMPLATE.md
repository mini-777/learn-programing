Fixes # issue_number

Changes proposed in this pull request: * * *